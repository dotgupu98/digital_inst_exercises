#include "stm32f30x_conf.h" // STM32 config
#include "30010_io.h" 		// Input/output library for this course
//#include "flash.h"
//#include "lcd.h"
//#include "string.h"

int main(void)
{
	uart_init( 9600 );
	//init_spi_lcd();

	//uint8_t fbuffer[512];
	//memset(fbuffer,0xAA,512);
	//lcd_push_buffer(fbuffer);
	//lcd_write_string("1line", fbuffer, 10, 0);
	//lcd_write_string("2line", fbuffer, 0, 1);
	//lcd_write_string("3line", fbuffer, 10, 2);
	//lcd_write_string("4line", fbuffer, 0, 3);
	//lcd_write_string("x      xx      xx      x", fbuffer, 0, 0);
	//lcd_write_string(" x    x  x    x  x    x", fbuffer, 0, 1);
	//lcd_write_string("  x  x    x  x    x  x", fbuffer, 0, 2);
	//lcd_write_string("   xx      xx      xx", fbuffer, 0, 3);

	//uint8_t a = 10;
	//char str[7];

	//lcd_push_buffer(fbuffer);


	//uint32_t address = 0x0800F800;
	//uint16_t tempVal=1624253;
	uint8_t alma=1211;
	//for ( int i = 0 ; i < 10 ; i++ ){
	//tempVal = *(uint16_t *)(address + i * 2); // Read Command
	//printf("%d ", tempVal);
	//}

	while(1){
		printf("%d ", alma);
	}
}
